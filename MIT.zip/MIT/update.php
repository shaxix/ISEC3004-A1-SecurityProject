<?php
// CSRF-protected version of the "update account email" page.
// Changes from the original:
//   1. The session is started at the top (it must happen before any HTML is sent).
//   2. The form now uses POST instead of GET, so the change is no longer a plain link/image request.
//   3. A per-session random token is embedded in the form and verified BEFORE any database work.
//      (The original reset the UserAccounts table on every request; now a forged request is
//      rejected before that can happen.)

session_name('update_demo');
session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'httponly' => true, 'samesite' => 'Lax']);
session_start();

function csrf_token(): string {
    if (empty($_SESSION['csrf_token']) || !is_string($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_valid(): bool {
    $sent = $_POST['csrf_token'] ?? '';
    $known = $_SESSION['csrf_token'] ?? '';
    return is_string($sent) && is_string($known) && $known !== '' && hash_equals($known, $sent);
}

function getDatabaseConnection() {
    $servername = "localhost";
    $username = "admin";
    $password = "admin";
    $dbName = "testDB2";

    $conn = new mysqli($servername, $username, $password, $dbName);

    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    $drop_query = "DROP TABLE IF EXISTS UserAccounts";
    if ($conn->query($drop_query) !== TRUE) {
        echo "Error dropping table: " . $conn->error;
    }

    $create_query = <<<_CREATE_
        CREATE TABLE IF NOT EXISTS UserAccounts (
          user_id INT(10) NOT NULL PRIMARY KEY AUTO_INCREMENT,
          user_name VARCHAR(100) NOT NULL,
          user_email VARCHAR(150) NOT NULL,
          user_password VARCHAR(100) NOT NULL
        )
_CREATE_;

    $result = $conn->query($create_query);
    if($result === FALSE) {
        die("Create failed: " . $conn->error);
    }

  $insert_queries = array();
  $insert_queries[] = <<<_INSERT_
      INSERT INTO UserAccounts (user_id, user_name, user_email, user_password)
      VALUES
        (1234, 'Tidus', 'tidus@example.com', '1234')
_INSERT_;
  $insert_queries[] = <<<_INSERT_
      INSERT INTO UserAccounts (user_id, user_name, user_email, user_password)
      VALUES
        (2222, 'Yuna', 'yuna@example.com', '1234')
_INSERT_;

    foreach ($insert_queries as $query) {
      if ($conn->query($query)) {
          //echo "Inserted row: $query\n";
      } else {
          echo "Error inserting row: " . mysqli_error($conn) . "\n";
      }
    }
    return $conn;
}

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$output = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) {
        // Reject before touching the database.
        http_response_code(403);
        $output = '<span style="color: red;">Request blocked: invalid or missing CSRF token. Nothing was changed.</span> <br>';
    } else {
        try {
            $conn = getDatabaseConnection();

            $user_id = $conn->real_escape_string($_POST['user_id'] ?? '');
            $new_email = $conn->real_escape_string($_POST['new_email'] ?? '');

            if (!empty($user_id) && !empty($new_email)) {
                $update_query =
                    "UPDATE UserAccounts SET user_email = '$new_email' where user_id = $user_id";
                $conn->query($update_query);
                $output .= "<span style=\"color: green;\">Email change successful!!</span> <br>";
                $output .= "User: $user_id, New email: $new_email <br>";

                $conn->close();
            }
        } catch (Exception $e) {
            $output = 'Error! ' . $e->getCode();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CSRF Update account email</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
	<div class="container">
		<div class="row justify-content-center" style="margin-top: 60px;">
			<div class="col-md-12">
				<h2 class="text center">Request to change email address</h2>
				<p class="text center">Please enter a new email</p>
				<form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
					<input type="hidden" name="csrf_token" value="<?php echo htmlspecialchars(csrf_token()); ?>">
					<div class="form-group mb-3">
						<label>Account ID</label>
						<input type="text" name="user_id" class="form-control" value="1234">
					</div>
					<div class="form-group mb-3">
						<label>New Email Address</label>
						<input type="text" name="new_email" class="form-control" placeholder="New email address">
					</div>
					<div class="form-group">
						<input type="submit" class="btn btn-primary" value="Change email">
					</div>
				</form>
				<?php if ($output !== '') echo '<div class="mt-3">' . $output . '</div>'; ?>
			</div>
		</div>
	</div>

</body>
</html>
