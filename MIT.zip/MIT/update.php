<?php

// Anti-CSRF token protection from updating emails page

// NOTE: the user accounts table gets reset after a submit meaning the accounts get deleted 
// 	if THIS page is sharing a database with the blog page
// TO AVOID ACCOUNT INFO DELETION: set RESET_DEMO_DATA to "false"

const RESET_DEMO_DATA = true;

mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

session_name('update_demo');
session_set_cookie_params([
    'lifetime' => 0,
    'path'     => '/',
    'httponly' => true,
    'samesite' => 'Lax',
]);
session_start();

// CSRF MITIGATION STRATEGY
// generates a random values token for each session
// validates the request by checking if the session token matches the request
function csrf_token(): string
{
    if (empty($_SESSION['csrf_token']) || !is_string($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }

    return $_SESSION['csrf_token'];
}

function csrf_valid(): bool
{
    $sent  = $_POST['csrf_token'] ?? '';
    $known = $_SESSION['csrf_token'] ?? '';

    return is_string($sent) && is_string($known) && $known !== '' && hash_equals($known, $sent);
}

function h($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}


function getDatabaseConnection(): mysqli
{
    $servername = 'localhost';
    $username   = 'admin';
    $password   = 'admin';
    $dbName     = 'testDB2';

    $conn = new mysqli($servername, $username, $password, $dbName);

    if ($conn->connect_error) {
        die('Connection failed: ' . $conn->connect_error);
    }

    if (RESET_DEMO_DATA) {
        resetDemoData($conn);
    }

    return $conn;
}

function resetDemoData(mysqli $conn): void
{
    $conn->query('DROP TABLE IF EXISTS UserAccounts');

    $conn->query('CREATE TABLE IF NOT EXISTS UserAccounts (
        user_id       INT(10)      NOT NULL PRIMARY KEY AUTO_INCREMENT,
        user_name     VARCHAR(100) NOT NULL,
        user_email    VARCHAR(150) NOT NULL,
        user_password VARCHAR(100) NOT NULL
    )');

    $conn->query("INSERT INTO UserAccounts (user_id, user_name, user_email, user_password)
                  VALUES (1234, 'Tidus', 'tidus@example.com', '1234')");
    $conn->query("INSERT INTO UserAccounts (user_id, user_name, user_email, user_password)
                  VALUES (2222, 'Yuna', 'yuna@example.com', '1234')");
}


$output = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) {
        http_response_code(403);
        $output = '<span style="color: red;">Request blocked: invalid or missing CSRF token. Nothing was changed.</span><br>';
    } else {
        $userId   = filter_var($_POST['user_id'] ?? '', FILTER_VALIDATE_INT);
        $newEmail = is_string($_POST['new_email'] ?? null) ? $_POST['new_email'] : '';

        if ($userId === false || $newEmail === '') {
            $output = '<span style="color: red;">Please enter a numeric account ID and a new email address.</span><br>';
        } else {
            try {
                $conn = getDatabaseConnection();

                $statement = $conn->prepare('UPDATE UserAccounts SET user_email = ? WHERE user_id = ?');
                $statement->bind_param('si', $newEmail, $userId);
                $statement->execute();
                $conn->close();

                $output  = '<span style="color: green;">Email change successful!!</span><br>';
                $output .= 'User: ' . h($userId) . ', New email: ' . h($newEmail) . '<br>';
            } catch (Exception $e) {
                $output = 'Error! ' . h($e->getCode());
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>CSRF Update account email</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <div class="row justify-content-center" style="margin-top: 60px;">
            <div class="col-md-12">
                <h2 class="text center">Request to change email address</h2>
                <p class="text center">Please enter a new email</p>

                <form method="POST" action="<?= h($_SERVER['PHP_SELF']) ?>">
                    <input type="hidden" name="csrf_token" value="<?= h(csrf_token()) ?>">

                    <div class="form-group mb-3">
                        <label>Account ID</label>
                        <input type="text" name="user_id" class="form-control" value="1234">
                    </div>

                    <div class="form-group mb-3">
                        <label>New Email Address</label>
                        <input type="text" name="new_email" class="form-control" placeholder="New email address">
                    </div>

                    <div class="form-group">
                        <input type="submit" class="btn btn-primary" value="Change email">
                    </div>
                </form>

                <?php if ($output !== ''): ?>
                    <div class="mt-3"><?= $output ?></div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>
